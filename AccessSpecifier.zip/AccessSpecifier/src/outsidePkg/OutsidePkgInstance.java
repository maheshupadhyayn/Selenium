package outsidePkg;

import withinPkg.WithinClass;

public class OutsidePkgInstance {
	public void byInstance() {
		WithinClass ins = new WithinClass();
		System.out.println(ins.age);
		//System.out.println(ins.name);
		//System.out.println(lName);
	}
	public static void main(String[] args) {
		OutsidePkgInstance a = new OutsidePkgInstance();
		a.byInstance();
	}
}
class OutsidePkgByInheritance extends WithinClass {
	public void byInheritance() {
		System.out.println(age);
		System.out.println(name);
		System.out.println(lName);
	}
}
//Public can be access within a class, within pakckage, outside package.
//Public can be access anywhere within same project
//Protected can be access outside package only with the help of inheritance
//Default can be access only within a package