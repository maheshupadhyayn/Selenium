package withinPkg;

public class WithinClass {
	private class PrivateClass {

	}

	public int age = 23;//public DM
	private int dept = 4;//Private DM
	protected String name = "Ashok";//Protected DM
	String lName = "XYZ";//Default DM
	public void withinClass() {
		System.out.println(age);
		System.out.println(dept);
		System.out.println(name);
		System.out.println(lName);
	}
}
//Outside of a class but within package by creating instance
class WithinPkgInstance {
	public void byInstance() {
		WithinClass ins = new WithinClass();
		System.out.println(ins.age);
		//System.out.println(ins.dept);private dm can't access outside of class
		System.out.println(ins.name);
		System.out.println(ins.lName);
	}
}
//Outside of a class but within package by inheritance
class WithinPkgByInheritance extends WithinClass {
	public void byInheritance() {
		System.out.println(age);
		//System.out.println(dept);
		System.out.println(name);
		System.out.println(lName);
	}
}
//Public can be access within a package
//protected can be access within same package
//Default can be access within same package





