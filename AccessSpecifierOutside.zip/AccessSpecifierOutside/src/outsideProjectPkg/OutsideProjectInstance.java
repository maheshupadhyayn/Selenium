package outsideProjectPkg;

import withinPkg.WithinClass;

public class OutsideProjectInstance {
	public void byInstance() {
		WithinClass ins  = new WithinClass();
		System.out.println(ins.age);
	}
}
class OutsideProByInheritance extends WithinClass {
	public void byInheritance() {
		System.out.println(age);
		System.out.println(name);
	}
}
//By adding dependancy of that project to current project
class ScienceClass {
	public int marks; //declare the marks variable which can access in child class
}
class Physics extends ScienceClass
{
	int intMarks=30;//initialize variable which hold the marks of internal
	int extMarks=50; //initialize variable which hold the marks of external
	public void add() {
		marks=intMarks+extMarks;//calculate the total marks
		System.out.println("Marks of physics -"+marks);//Print the mark
	}
}