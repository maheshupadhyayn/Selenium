package commonFunction;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.DataProvider;

public class LoginMedifox {
  @Test(dataProvider = "dp")
  public void login(String url, String user, String pass, String browser) {
	  WebDriver driver = WebBrowser.openBrowser(browser);
	  WebBrowser.openURL(driver, "https://nursingdemo.medifox.in.net/Account/Login");
	  WebTextBox.enterText(driver, By.id("Username"), user);
	  WebTextBox.enterText(driver, By.id("Password"), pass);
	  WebButton.click(driver, By.xpath("//input[@type='submit']"));
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "url", "admin", "admin", "chrome"},
      new Object[] { "url", "admin", "admin", "edge" },
      new Object[] { "url", "abc", "admin", "chrome" },
      new Object[] { "url", "abc", "admin", "edge" },
      new Object[] { "url", "admin", "12345", "chrome" },
      new Object[] { "url", "admin", "12345", "edge" },
      new Object[] { "url", "@#$%", "admin", "chrome" },
      new Object[] { "url", "@#$%", "admin", "edge" },
      new Object[] { "url", "admin", "@#$%", "chrome" },
      new Object[] { "url", "admin", "@#$%", "edge" },
      new Object[] { "url", "", "admin", "chrome" },
      new Object[] { "url", "", "admin", "edge" },
      new Object[] { "url", "admin", "", "chrome" },
      new Object[] { "url", "admin", "", "edge" },
      new Object[] { "url", "", "", "chrome" },
      new Object[] { "url", "", "", "chrome" },
    };
  }
}
