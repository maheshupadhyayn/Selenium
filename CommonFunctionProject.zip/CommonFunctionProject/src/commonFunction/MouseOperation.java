package commonFunction;

public class MouseOperation {
/*
 * movetoelement
 * Drag and drop
 * Right click
 * Click
 * Double Click
 * 
 */
}
