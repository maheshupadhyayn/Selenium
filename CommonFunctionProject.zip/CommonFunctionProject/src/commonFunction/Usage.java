package commonFunction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Usage {
	@Test(dataProvider = "dp")
	public void TC1(String browser, String fname, String mail) {
		//WebDriver driver = WebBrowser.openBrowser(browser);
		WebDriver driver = WebBrowser.openURL(WebBrowser.openBrowser(browser), 
				"https://www.knowledgeware.in/Automation/index.html");
		
		WebElement fName = driver.findElement(By.id("fname"));
		WebTextBox.enterText(fName, fname);
		
		WebTextBox.enterText(driver, By.id("mailid"), mail);
	}
	
	@DataProvider
	  public Object[][] dp() {
	    return new Object[][] {
	      new Object[] { "chrome","shruti", "Sharvari@gmail.com" },
	      new Object[] { "edge", "Omkar", "Narendra@gmail.com" },
	    };
	  }
}
