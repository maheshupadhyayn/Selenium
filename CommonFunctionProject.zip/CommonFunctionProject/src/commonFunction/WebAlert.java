package commonFunction;

public class WebAlert {
/*
 * accept alert
 * dismiss alert
 * enter text
 * gettext
 */
}
