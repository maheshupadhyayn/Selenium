package commonFunction;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebButton {
	public static void click(WebElement button) {
		if(WebElementCommon.isClickable(button)) {
			button.click();
		}
	}
	public static void click(WebDriver driver, By by) {
		WebElement button = WebElementCommon.isClickable(driver, by);
		button.click();
	}
}
