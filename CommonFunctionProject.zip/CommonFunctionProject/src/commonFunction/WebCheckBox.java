package commonFunction;

public class WebCheckBox {

}
