package commonFunction;

public class WebDropDown {
/*
 * selectbyindex
 * byvalue
 * byvisible text
 * deseltall
 * deselect value
 * 
 */
}
