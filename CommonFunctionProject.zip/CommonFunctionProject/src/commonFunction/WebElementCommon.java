package commonFunction;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebElementCommon {
	public static WebElement isClickable(WebDriver driver, By by) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		return wait.until(ExpectedConditions.elementToBeClickable(by));
	}
	
	public static WebElement isClickable(WebDriver driver, int sec, By by) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(sec));
		return wait.until(ExpectedConditions.elementToBeClickable(by));
	}
	
	public static WebElement isClickable(WebDriver driver, int sec, int poll, By by) {
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
								.withTimeout(Duration.ofSeconds(sec))
								.pollingEvery(Duration.ofSeconds(poll))
								.ignoring(NoSuchElementException.class);
		return wait.until(ExpectedConditions.elementToBeClickable(by));
	}
	
	public static boolean isPresent(WebElement element) {
		boolean isPre = false;
		if(element.isDisplayed()) {
			isPre = true;
		}
		return isPre;
	}
	
	public static boolean isClickable(WebElement element) {
		boolean isClick = false;
		if(isPresent(element)) {
			if(element.isEnabled()) {
				isClick = true;
			}
		}
		return isClick;
	}
	
}







