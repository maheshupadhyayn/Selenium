package commonFunction;

public class WebFrame {
/*
 * switchtoframe by element
 * by id/name
 * by index
 */
}
