package commonFunction;

public class WebRadioButton {

}
