package constructorPkg;

public class BasicsConstructor {
	/*
	 * Rule 1 - Constructor is looks like a method/function, 
	 * 			which will return object/instance/reference of class
	 * Rule 2 - Constructor is having same name as class name
	 * Rule 3 - Constructor does not have any return type
	 * Rule 4 - Whenever there is constructor in a class and you create object
	 * 			of that class, then constructor calls first
	 * Rule 5 - JVM Creates runtime constructor only if no constructor availble within class
	 * Rule 6 - Constructor can be overloaded
	 * 
	 * How many types of constructor?
	 * Ans - There are 4 types
	 * 		a - Default constructor - JVM creates at runtime, if there is no constructor available
	 * 		b - Parameterized Constructor - user defined
	 * 		c - Copy Constructor
	 * 		d - Constructor Chaining
	 * 
	 * Why Constructor?
	 * Ans - Because to do implementation/setup before accessing a class
	 */
	public BasicsConstructor() {
		System.out.println("Hello Ankur");
	}
	
	public static void add() {
		System.out.println("Hello Akshata");
	}
	public static void main(String[] args) {
		System.out.println("Hello Akshata");
		BasicsConstructor instance = new BasicsConstructor();
		System.out.println("Hello Rupali");
	}
}
