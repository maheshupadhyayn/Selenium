package constructorPkg;

public class ConstructorChaining {
	public static void main(String[] args) {
		Child ins = new Child(42, "Akshay");
		System.out.println(ins.age+" --- "+ ins.name);
	}
}
class Parent {
	String name;
	public Parent(String name) {
		this.name = name;
	}
}
class Child extends Parent{
	int age;
	public Child(int age, String name) {
		//new Parent(name);
		super(name);//reffers to parent class
		this.age = age;//reffers to current/child class
		//super(name);
		//super will be always a first statement in calling method
	}
}