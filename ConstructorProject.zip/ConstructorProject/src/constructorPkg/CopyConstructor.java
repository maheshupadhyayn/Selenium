package constructorPkg;

public class CopyConstructor {
	int age;
	String name;
	public CopyConstructor(int age, String name) {
		this.age = age;
		this.name = name;
	}
	public CopyConstructor(CopyConstructor c) {
		age = c.age;
		name = c.name;
	}
	
	public static void main(String[] args) {
		CopyConstructor narendra = new CopyConstructor(39, "Narendra");
		CopyConstructor ashok = new CopyConstructor(narendra);
		System.out.println(ashok.age+" --- "+ ashok.name);
	}
}
class WebElement {
	String driver;
	public WebElement(String driver) {
		this.driver = driver;
	}
}
class WebButton {
	String driver;
	public WebButton(WebElement e) {
		driver = e.driver;
	}
}
class WebTextBox {
	String driver;
	public WebTextBox(WebElement e) {
		driver = e.driver;
	}
}

















