package constructorPkg;

public class ParametrizedConstrcutor {
	ParametrizedConstrcutor() {
		System.out.println("Without paramter");
	}
	ParametrizedConstrcutor(int a) {
		System.out.println("My age is "+a);
	}
	public ParametrizedConstrcutor(String name) {
		System.out.println("My name is "+name);
	}
	public static void main(String[] args) {
		ParametrizedConstrcutor ins = new ParametrizedConstrcutor();
		ParametrizedConstrcutor ins1 = new ParametrizedConstrcutor(23);
		ParametrizedConstrcutor ins2 = new ParametrizedConstrcutor("Rupali");
	}
}
