package constructorPkg;

public class ParametrizedDemo {
	int age;
	String name;
	public ParametrizedDemo(int a, String n) {
		age = a;
		name = n;
	}
	public void print() {
		System.out.println("My age is - "+age+" My name is - "+name);
	}
	public static void main(String[] args) {
		ParametrizedDemo teertha = new ParametrizedDemo(24, "Teertha");
		teertha.print();
		ParametrizedDemo sonu = new ParametrizedDemo(22, "Sonu");
		sonu.print();
	}
}
class Locator {
	String driver;
	public Locator(String browser) {
		driver = browser;
	}
}
class Action {
	public void launchBrowser() {
		//Open browser
		String browser = "chrome";
		Locator l = new Locator(browser);
	}
}



