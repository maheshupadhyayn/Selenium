package constructorPkg;

public class RealTimeConstructor {

}
class BaseClass {
	String driver = "Chrome";
}

class TestClass extends BaseClass {
	public void TC1() {
		Action actionPA = new Action(driver);
		actionPA.enterUserName();
	}
}

class Action {
	String driver;
	Locator locPL;
	public Action(String driver) {
		this.driver = driver;
		locPL = new Locator(driver);
	}
	
	public void enterUserName() {
		locPL.getUserName();//enter user name
	}
}

class Locator {
	String driver;
	
	public Locator(String driver) {
		this.driver = driver;
	}
	
	public String getUserName() {
		return "user";
	}
}