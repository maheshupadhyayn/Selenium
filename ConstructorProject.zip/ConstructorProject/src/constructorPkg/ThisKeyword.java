package constructorPkg;

public class ThisKeyword {
	String name;
	public ThisKeyword(String name) {
		this.name = name;
		//this reffers to the current class
	}
}
