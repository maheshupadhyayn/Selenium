package exceptionPkg;

public class BasicsException {
/*
 * Exception - If developer writes a code, which is breaking due to some logical/implementation
 * 			   issues. which can be handle by code and fixed is called Exception
 * Error - JVMRunningOutOfMemory, StackOverflow, VirtualMachineError, which can not be handled by 
 * 			code is called error
 * 
 * Exception Types - 2
 * 		1 - Compile Time - Checked Exception
 * 		2 - Run Time - Unchecked Exception
 */
}
