package exceptionPkg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class CheckedException {
	public static void main(String[] args) throws FileNotFoundException {
		InputStream file = new FileInputStream("C://a.txt");
	}
	//throws is a keyword which works always with method signature
	//throws will help you to postpone the exception
}
