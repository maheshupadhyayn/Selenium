package exceptionPkg;

public class Difference2 {
	//final, finally, finalize()
	final int age = 23;//Value is final, not able to change, PI
	final static String name = "Sonu";//Constant, final & static we called
	//it as a constant
	public int ageIncre() {
		age = 24;
		return age;
	}
	public static void main(String[] args) {
		Difference2 i = new Difference2();
		System.out.println(i.ageIncre());
	}
}
/*
final is a keyword
finally is a block
*/