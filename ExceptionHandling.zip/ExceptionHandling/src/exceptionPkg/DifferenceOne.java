package exceptionPkg;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class DifferenceOne {
	public static void checkException() throws FileNotFoundException {//postpone the exception
		InputStream file = new FileInputStream("C://a.txt");		
	}
	public static void uncheckedException() {
		int num = 100;
		int deviser = 0;
		try {//protected code
			System.out.println(num/deviser);
		} catch (ArithmeticException e) {
			throw e;//trigger the exception
		}
	}
	public static void main(String[] args) {
		uncheckedException();
	}
	/*
	 * throws - will help to postpone the exception
	 * throw -  will trigger the exception
	 * 
	 * throws - will work always with method signature
	 * throw  - will work within a catch block
	 */
}
