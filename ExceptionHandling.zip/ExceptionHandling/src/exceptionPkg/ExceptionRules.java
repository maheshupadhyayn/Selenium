package exceptionPkg;

public class ExceptionRules {
/*
 * Rule 1 - Can we have 1 try and 1 catch? Yes
 * Rule 2 - Can we have 1 try and 1 finally, no catch? Yes
 * Rule 3 - Can we have only catch and finally without try? No, catch works only on protected code
 * Rule 4 - Can we have only catch without try? No, try is must
 * Rule 5 - Can we have only finally without try? No, try is must
 * Rule 6 - Can we have 1 try and multiple catch? Yes
 * Rule 7 - Can we have multiple try and 1 catch? No
 * Rule 8 - Try always works either with catch or finally, alone it throws error
 * Rule 9 - Can we have 1 try and multiple finally? No, finally is always once in syntax
 * Rule 10 - Can we have multiple try/catch block in same method/function? Yes
 * Rule 11 - Can we have try/catch within try? Yes
 * Rule 12 - Can we have try/catch within catch? Yes
 * Rule 13 - Can we have try/catch within finally? Yes
 * Rule 14 - Can we have try/catch/finally within finally? Yes
 */
	public void rule14() {
		try {
			//exception 2
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				//exception 2
			} catch (Exception e) {
				// TODO: handle exception
			} finally {
				try {
					//exception 2
				} catch (Exception e) {
					// TODO: handle exception
				} finally {
					try {
						//exception 2
					} catch (Exception e) {
						// TODO: handle exception
					} finally {
						
					}
				}
			}
		}
	}
	public void rule13() {
		try {
			//exception 2
		} catch (Exception e) {
			// TODO: handle exception
		} finally {
			try {
				//exception 2
			} catch (Exception e) {
				// TODO: handle exception
			} 
		}
	}
	public void rule12() {
		try {
			//exception 1
		} catch (Exception e) {
			try {
				//exception 2
			} catch (Exception e1) {
				try {
					//exception 2
				} catch (Exception e2) {
					try {
						//exception 2
					} catch (Exception e3) {
						// TODO: handle exception
					}
				}
			}
		}
		
	}
	public void rule11() {
		try {
			try {
				try {
					try {
						System.out.println(100/0);
					} catch (Exception e) {
						// TODO: handle exception
					}
				} catch (Exception e) {
					// TODO: handle exception
				}
			} catch (Exception e) {
				// TODO: handle exception
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	public void rule10() {
		try {
			//exception 1
		} catch (Exception e) {
			// TODO: handle exception
		}
		try {
			//exception 2
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public void rule9() {
		try {
		} finally {
			
		} finally {
			
		}finally {
			
		}
	}
	public void rule8() {
		try {
			
		}
	}
	public void rule7() {
		try {
			
		} try{
			
		}catch (ArithmeticException e) {
			System.out.println("I got exception");
		} 
	}
	public void rule6() {
		try {
			
		} catch (ArithmeticException e) {
			System.out.println("I got exception");
		} catch(NullPointerException e1){
			System.out.println(100/10);
		} catch(ArrayIndexOutOfBoundsException e2) {
			
		} catch(Exception e3) {
			//Parent class/exception will be always last in multiple catches
		}
	}
	public void rule5() {
		finally {
			System.out.println(100/10);
		}
	}
	public void rule4() {
		catch (ArithmeticException e) {
			System.out.println("I got exception");
		} 
	}
	public void rule3() {
		catch (ArithmeticException e) {
			System.out.println("I got exception");
		} finally {
			System.out.println(100/10);
		}
	}
	public void rule2() {
		try {
			System.out.println(100/10);
		} finally {
			System.out.println("I got exception");
		} 
	}
	public void rule1() {
		try {
			System.out.println(100/10);
		} catch (ArithmeticException e) {
			System.out.println("I got exception");
		} 
	}
}
