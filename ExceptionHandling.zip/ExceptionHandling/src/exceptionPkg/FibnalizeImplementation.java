package exceptionPkg;

public class FibnalizeImplementation {
	protected void finalize() {
		System.out.println("I am finalize");
	}
	public static void main(String[] args) {
		FibnalizeImplementation instance = new FibnalizeImplementation();
		instance = null;
		System.gc();
		System.out.println("Release my object");
	}
}
/*
final is a keyword use for making constant
finally is a block use for exception handling
finalize is a method to use for garbage collection
*/