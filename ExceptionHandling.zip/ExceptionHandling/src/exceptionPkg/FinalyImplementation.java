package exceptionPkg;

public class FinalyImplementation {
	public static void main(String[] args) {
		try {
			System.out.println(100/10);
		} catch (ArithmeticException e) {
			System.out.println("I got exception");
		} finally {//I execute always even exception comes or not come
			System.out.println("Execute always");
		}
	}
}
