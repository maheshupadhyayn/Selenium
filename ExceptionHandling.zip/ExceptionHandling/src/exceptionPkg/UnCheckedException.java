package exceptionPkg;

public class UnCheckedException {
	public static void main(String[] args) {
		int[] arr = {23, 5, 89, 56};
		int index = 900;
		try {//protected code
			System.out.println(arr[index]);
		} catch (Exception e) {//Trigger action if protected code fails
			System.out.println("Shruti you received an exception chalo fix karo");
			while(index>=arr.length-1) {
				index--;
			}
			System.out.println(arr[index]);
		}
	}
}
