package exceptionPkg;

public class UncheckException4 {
	public static String getBrowser(String browser) {
		String driver = null;
		switch(browser) {
			case "mozilla":
				driver = "Mozilla";
				break;
			case "Chrome":
				driver = "chrome";
				break;
			case "safari":
				driver = "safari";
				break;
			case "edge":
				driver = null;
		}
		return driver;
	}
	
	public static void main(String[] args) {
		try {
			System.out.println(getBrowser("IE"));
		} catch (NullPointerException e) {
			getBrowser("Chrome");
		}
		
	}
}




