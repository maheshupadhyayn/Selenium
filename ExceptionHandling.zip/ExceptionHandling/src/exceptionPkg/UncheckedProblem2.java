package exceptionPkg;

public class UncheckedProblem2 {
	public static void main(String[] args) {
		int num = 100;
		int deviser = 5;
		try {//protected code
			System.out.println(num/deviser);
		} catch (ArithmeticException e) {//action, if exception comes then only it comes to catch block
			if(deviser==0) {
				deviser+=3;
				System.out.println(num/deviser);
			}
		}
	}
}
