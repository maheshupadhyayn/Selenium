package exceptionPkg;

public class UncheckedProblem3 {
	public static void main(String[] args) {
		String name = null;
		try {
			System.out.println(name.length());
		} catch (NullPointerException e) {
			if(name==null) {
				name="";
				System.out.println(name.length());
			}
		}
	}
}
