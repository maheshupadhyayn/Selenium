package abstractionPkg;

public class AbsA {
	void a() {}
	void b() {}
	void c() {}
	public static void main(String[] args) {
		ChromeDriver d = new ChromeDriver();
		d.findElement();
		SafariDriver s = new SafariDriver();
		s.findElement();
	}
}

abstract class AbsB extends AbsA {
	
}
