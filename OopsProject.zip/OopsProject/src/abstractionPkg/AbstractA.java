package abstractionPkg;

public abstract class AbstractA {//4 - All Abstract
	abstract void add();
	abstract void multiply();
	abstract void devide();
	abstract void subtract();
}
abstract class AbstractB extends AbstractA {//6 - abstract - 2, non abstract - 4
	void add() {} // Override
	void multiply () {} //Override
	void a() {}
	void b() {}
}
class AbstractC extends AbstractB {
	void subtract() {}
	void devide() {}
}
