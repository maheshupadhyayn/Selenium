package abstractionPkg;
//data hiding
public abstract class AbstractionClass {
	/*
	 * Rule 1 - Abstract method has only declaration no implementation
	 * 			a - we need to add abstract keyword
	 * 			b - Only declaration ";" , no implementation {}
	 * Rule 2 - If any of the method within a class is abstract then class should be abstract class
	 * Rule 3 - Abstract class can hold abstract as well as non abstract method
	 * Rule 4 - Abstract class supports abstraction between 0%-100%
	 * Rule 5 - We can make a class as an abstract even we don't have abstract method
	 * Rule 6 - We cannot instatiate/create object of abstract class java says
	 * Rule 7 - Abstraction support another oops concept name as inheritance to support
	 * 			method overriding
	 */
	public abstract void add();
	public void devide() {}
	public void multiply() {}
}

class AccessAbstract {
	public void access() {
		AbstractionClass inst = new AbstractionClass() {
			public void add() {}
		};
	}
}
//To remove an error
//Solution 1 - We can make child class as abstract
abstract class AnstractChild extends AbstractionClass{
	public void access() {
		
	}
}
//Solution 2 - We can override the abstract method
class AnstractChild1 extends AbstractionClass{
	public void add() {}//Method overriding
	public void access() {
		
	}
}


