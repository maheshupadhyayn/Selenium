package abstractionPkg;

public abstract class RemoteWebDriver {
	abstract void get();
	abstract String findElement();
	void getText() {}
}
class ChromeDriver extends RemoteWebDriver {
	void get() {}//Override
	String findElement() {return "chrome";}
}

class SafariDriver extends RemoteWebDriver {
	void get() {}//Override
	String findElement() {return "safari";}
}

class EdgeDriver extends RemoteWebDriver {
	void get() {}//Override
	String findElement() {return "edge";}
}