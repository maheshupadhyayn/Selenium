package encapsulationPkg;

public class EmployeeCalling {
	public static void main(String[] args) {
		EmployeeName rupali = new EmployeeName();
		rupali.setName("Rupali");
		System.out.println(rupali.getName());
		
		EmployeeName aksh = new EmployeeName();
		aksh.setName("Akshata");
		System.out.println(aksh.getName());
	}
}

class EmployeeName {
	private String name;
	private int dept;
	public void setName(String n) {
		name = n;
	}
	public String getName() {
		return name;
	}
	public int accessDept() {
		return dept;
	}
}