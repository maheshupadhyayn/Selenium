package encapsulationPkg;

public class EncapsulationCalling {
	//multiple DM's to be club together - Data Binding
	//Private DM can be access outside of a class with the help of public getter or setter
	public static void main(String[] args) {
		
	}
}
class EncapsulateParent {
	private int age = 23;//Private DM can be access only within a same class
	public void accParent() {
		System.out.println(age);
	}
	//How to access private DM outside of a class? - By Encapsulation
	public int getAge() {
		return age;
	}
}

class InheritancePrivate extends EncapsulateParent {
	public void access() {
		//System.out.println(age);//Private DM can not be inherited
		System.out.println(getAge());
	}
}

class InstancePrivate {
	public void access() {
		EncapsulateParent inst = new EncapsulateParent();
		inst.accParent();
		//System.out.println(inst.age);//Private DM can not be instatiated outside of a class
		//System.out.println(EncapsulateParent.age);
		System.out.println(inst.getAge());
	}
}
//Asked Inheritance question to Shruti, Akshata & Priyanka