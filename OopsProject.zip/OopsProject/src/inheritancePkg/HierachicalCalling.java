package inheritancePkg;
//One Parent and Multiple Child
public class HierachicalCalling {
	public static void main(String[] args) {
		HierachicalChild1 ins = new HierachicalChild1();
		System.out.println(ins.dept);
	}
}
class HierachicalParent {
	String dept = "IT";
}

class HierachicalChild1 extends HierachicalParent {
	String name = "Sonu";
}

class HierachicalChild2 extends HierachicalParent {
	String name = "Priyanka";
}

class BaseClass {
	String driver = "Chrome";
}

class LoginTest extends BaseClass {
	
}

class InboxTest extends BaseClass {
	
}

class OutboxTest extends BaseClass {
	
}





















