package inheritancePkg;

public class MultiLevelCalling {

}
