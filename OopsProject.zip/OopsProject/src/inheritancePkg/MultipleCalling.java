package inheritancePkg;

public class MultipleCalling {
	public static void main(String[] args) {
		MultipleChild i = new MultipleChild();
		System.out.println(i.age);
		System.out.println(i.name);
		System.out.println(i.dep);
		i.add();
	}
}

class MultipleParent1 {//DM-1 age
	int age = 23;
	public void add() {}
}
class MultipleParent2 {//DM 1 name
	String name = "Ajinkya";
	public void add() {}
}
//Java says multiple inheritance is not possible for classes
//Why - to avoid ambiguity/confusion
class MultipleChild extends MultipleParent1, MultipleParent2 {//DM 3
	int dep = 4;
}