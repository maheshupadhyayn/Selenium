package inheritancePkg;
//One parent and one Child is called single inheritance
//Property - DM
//Inheritance - Aquire property of parent to child
public class SingleParent {//DM - 1 age
	int age = 23;
	public static void main(String[] args) {
		SingleParent ins = new SingleParent();
		System.out.println(ins.age);
		//System.out.println(ins.dept);
		SingleChild i = new SingleChild();
		System.out.println(i.dept);
		System.out.println(i.age);
	}
}

class SingleChild extends SingleParent {//DM - 1 dept  2 age
	int dept = 4;
}