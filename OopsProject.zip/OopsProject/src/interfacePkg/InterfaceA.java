package interfacePkg;

public interface InterfaceA {
	void add();
}

interface InterfaceB {
	void add();
}

class InteA implements InterfaceA, InterfaceB {
	public void add() {}
	public void devide() {}
}
class CallInter {
	public void access() {
		InteA a = new InteA();
		a.add();
	}
}

abstract class A {
	abstract void add();
	void b() {}
}
abstract class B {
	abstract void add();
}
class C extends A,B{
	
}