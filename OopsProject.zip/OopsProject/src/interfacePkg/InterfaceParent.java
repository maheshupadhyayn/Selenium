package interfacePkg;

public interface InterfaceParent {
	/*
	 * Rule 1 - By default all the methods are abstract in interface
	 * Rule 2 - Interface supports 100% abstraction
	 * Rule 3 - Support method overriding, which internally support inheritance
	 * Rule 4 - We can't create instance of interface
	 */
	void add();
	void subtract();
	void devide();
}
//Inheritance
abstract class InteA implements InterfaceParent {
	
}
class IntB implements InterfaceParent {
	static void add() {}
	public void subtract() {}
	public void devide() {}
}

interface A{
	void a();
	void b();
}
interface B extends A {
	void c();
	void d();
}
/*
Sub Class - Child Class
Super Class - Parent Class

SubClass-Child CLass   ------ SuperCLass - ParentClass      -------   Keyword
      class								class							extends
      interface							class							Not possible
      interface							interface						extends	
      class								interface						implements						



*/