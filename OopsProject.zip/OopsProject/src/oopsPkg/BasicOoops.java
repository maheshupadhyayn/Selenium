package oopsPkg;

public class BasicOoops {
/*
 * What is OOPs?
 * Ans - Object Oriented Programming Structure
 * 
 * Why OOPS?
 * Ans - Reusability, Optimization, Data Hiding, Binding, Security
 * 
 * How many OOPS principle?
 * Ans - As per Java it is 4, but if you asked me it is 7
 * 		1 - Class - Is a template, it's a collection of Object
 * 		2 - Object - Its a collection of DM
 * 		3 - Instance - Just a reference to an Object
 * 		4 - Inheritance - Aquire property of parent to child
 * 		5 - Polymorphisam - One task can be performed by multiple way
 * 			a - Method Overloading - Within Class - Compile Time Poly, Early Bindind, Static
 * 			b - Method Overriding - Outside Class - Runtime Poly, Late Binding, Dynamic
 * 		6 - Encapsulation
 * 		7 - Abstraction
 */
	public static void main(String[] args) {
		String s = "abc";
		s.getbyte
	}
}
