package oopsPkg;

public class ClassA {
	int age = 23;
	public static void main(String[] args) {
		//age is a variable of type int which holds a value 23
		int age = 23;
		//instance is a type of classB which refers to object classB()
		ClassB instance = new ClassB();
		//class inst/ref = object
		instance.add();
		new ClassB().add();
	}
}
class ClassB {
	String name;
	public void add() {}
}
class ClassC {
	int Dept;
	public void devide() {}
}