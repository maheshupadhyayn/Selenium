package polyPkg;
//Within Same class
public class MethodOverloading {
	/*
	 * Rule 1 - Always within a same class
	 * Rule 2 - Same method name but different number of input parameters
	 */
	void add() {}
	void add(int a) {}
	void add(int a, int b) {}
	/*
	 * Rule 3 - Same method name, same number of param, but data type is different
	 */
	void add(char a, char b) {}
	void add(String a, String b) {}
	/*
	 * Rule 4 - Same method name, same number of param, but order is different
	 */
	void add(char a, String b) {}
	void add(String a, char b) {}
	/*
	 * Rule 5 - Return type does not matters, what matters
	 * Always method name and input param(Data Type) should not same
	 */
	int add() {return 1;}
	
	void print(int a, int b, int c) {}
	void print(int x, int y, char z) {}
	
	
	
	
	
	
}
