package polyPkg;

public class MethodOverriding {
	
	public static void main(String[] args) {
		AutomationTool inst;	
		int age;
		age = 10;
		//User selected soapUI
		inst = new SoapUI();
		System.out.println(inst.getToolCost());
		//User selected Selenium
		age = 20;
		inst = new Selenium();
		System.out.println(inst.getToolCost());
	}
}
/*
 * Rule 1 - Method overriding is always outside of a class
 * Rule 2 - Method overriding support inheritance
 * Rule 3 - Method overriding means same method name, same number of param, same data type
 * 			same order (Same signature) only implementation is different
 * Rule 4 - Return type matters
 */
class AutomationTool {
	int getToolCost() {return 0;}
}
//can we overload a overridden method - Yes
class QTP extends AutomationTool {
	int getToolCost() {return 10000;}//Overridden method
	String getToolCost(int a) {return "a";}//Overloaded method
}
class Selenium extends AutomationTool {
	int getToolCost() {return 5000;}
}
class SoapUI extends AutomationTool {
	int getToolCost() {return 8000;}
}