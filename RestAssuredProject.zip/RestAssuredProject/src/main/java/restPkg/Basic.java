package restPkg;

public class Basic {
	public static void main(String[] args) {
		
	}
}
