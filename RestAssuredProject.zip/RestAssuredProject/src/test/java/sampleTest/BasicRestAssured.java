package sampleTest;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class BasicRestAssured {
	public static void main(String[] args) {
		//Precondition define as your base URL, RestAssured is a class
		RestAssured.baseURI = "https://gorest.co.in/public";
		//Prpeare a request which i need to send server, requestspec is interface
		RequestSpecification reqSpec = RestAssured.given();
		//I have to send Get method, if required any parameters
		Response response = reqSpec.get("/v2/users");
		//Print the response
		System.out.println(response.prettyPrint());
	}
}
/*
 * GWT - BDD (Behavior Driven Development)
 * G - Given - Precondition/Pre-requistes
 * W - When - Action
 * T - Then - Expected Results
 */
