package seleniumPkg;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertImplementation {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/alerts.html");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@onclick='alertfxn()']")).click();
		//Get the alert by switching to it
		Alert alert = driver.switchTo().alert();
		//I want to click on Ok, Yes, Agree,continue
		Thread.sleep(2000);
		alert.accept();
		//Delay in 5 secs
		driver.findElement(By.xpath("//button[@onclick='alertfive()']")).click();
		Thread.sleep(8000);
		alert = driver.switchTo().alert();
		alert.accept();
		//Confimation box
		driver.findElement(By.xpath("//button[@onclick='confirmbtn()']")).click();
		Thread.sleep(1000);
		alert = driver.switchTo().alert();
		//I want to click on cancel, No, Dis-Agree,Not to continue
		alert.dismiss();
		//Enter name to alert text box
		driver.findElement(By.xpath("//button[@onclick='promptbtn()']")).click();
		Thread.sleep(1000);
		alert = driver.switchTo().alert();
		//I want to enter Bhushan as a name to alert and accept
		alert.sendKeys("Bhushan");
		Thread.sleep(3000);
		alert.accept();
	}
	//Selenium automates only web alert(Pop Up) not windows alert
}
