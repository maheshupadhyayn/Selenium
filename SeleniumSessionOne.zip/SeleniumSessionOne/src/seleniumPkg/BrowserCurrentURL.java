package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCurrentURL {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.yahoo.com");
		
		Thread.sleep(3000);
		driver.findElement(By.linkText("Finance")).click();

		Thread.sleep(3000);
		String currentUrl = driver.getCurrentUrl();
		String expectedURL = "https://finance.yahoo.com/";
		if(currentUrl.equals(expectedURL)) {
			System.out.println("We redirect to correct page");
		}
	}
}
