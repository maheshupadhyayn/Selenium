package seleniumPkg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserPageSource {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.Yahoo.com");

		Thread.sleep(3000);
		
		String pageSrc = driver.getPageSource();
		System.out.println(pageSrc);
		if(pageSrc.contains("Terms and Condition")) {
			
		}
		if(pageSrc.contains("abc"
				+ "my name is"
				+ "do we perform automation"
				+ "")) {
			
		}
	}
}
