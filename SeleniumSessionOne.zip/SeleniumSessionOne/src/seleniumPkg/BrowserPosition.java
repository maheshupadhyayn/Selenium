package seleniumPkg;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserPosition {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/final.html");
		Thread.sleep(3000);
		//I am getting a position of browser window
		Point point = driver.manage().window().getPosition();
		System.out.println("X Offset/Axis - "+point.x+
				" Y Offset/Axis - "+point.y);
		Thread.sleep(5000);
		//Set position will help you set browser new pointer/position
		Point newPoint = new Point(348, 157);
		driver.manage().window().setPosition(newPoint);
	}
}
