package seleniumPkg;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserSize {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/final.html");
		//We will get the current browser window size and print
		Dimension dim = driver.manage().window().getSize();
		//This command will give size of upor open browser window
		int height = dim.getHeight();//Returns a height of current dimesion
		int width = dim.getWidth();// returns a width of current dimesion
		System.out.println("Current browser Height is: - "+height+
				" Current browser width is -"+width);
		Thread.sleep(3000);
		Dimension newDim = new Dimension(500, 800);
		//I want to set a new dimesion to my open browser window
		driver.manage().window().setSize(newDim);
	}
}
