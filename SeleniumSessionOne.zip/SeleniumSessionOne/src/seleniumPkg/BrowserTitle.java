package seleniumPkg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserTitle {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.Yahoo.com");

		Thread.sleep(3000);
		
		String actualTitle = driver.getTitle();//GetTitle will return the title of web page
		String expectedTitle = "Google";
		
		if(expectedTitle.equals(actualTitle)) {
			System.out.println("Correct Page Opens");
		}
	}
}
