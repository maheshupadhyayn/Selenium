package seleniumPkg;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserWindowHandles {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.yahoo.com");
		
		Thread.sleep(3000);
		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.get("https://www.google.co.in");

		Thread.sleep(3000);
		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.get("https://money.rediff.com/index.html");
		
		Thread.sleep(3000);
		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.get("https://www.amazon.co.in");

		Set<String> names = driver.getWindowHandles();
		for(String name:names) {
			System.out.println(name);
			System.out.println(driver.switchTo().window(name).getTitle());
		}
		//getttile() method will return you the title of web page you open
	}
}







