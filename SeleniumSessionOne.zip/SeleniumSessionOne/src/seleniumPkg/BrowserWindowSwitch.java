package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserWindowSwitch {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.yahoo.com");
		String parentWindow = driver.getWindowHandle();
		//Getwindowhandle will return you a String with 
		//current browser window open
		
		Thread.sleep(3000);
		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.get("https://www.google.co.in");
		String childWindow = driver.getWindowHandle();
		
		Thread.sleep(3000);
		driver.switchTo().window(parentWindow);//Parent window switch(Yahoo)
		//operation perform
		driver.findElement(By.name("p")).sendKeys("Sachin Tendulkar");
		
		Thread.sleep(3000);
		driver.switchTo().window(childWindow);
		//operation perform
		driver.findElement(By.name("q")).sendKeys("Sachin Tendulkar");
		
	}
}
