package seleniumPkg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxImplementation {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_input_type_checkbox");
		//Switch to frame for accessing all webelement under that frame
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		//- //tagname[@attrName ='attrVal']
		List<WebElement> checkBoxes = driver.findElements(By.xpath("//input[@type='checkbox']"));
		for(WebElement checkBox : checkBoxes) {
			String vehicleName = checkBox.getAttribute("value");
			if(vehicleName.equals("Car") || vehicleName.equals("Boat")) {
				if(!checkBox.isSelected()) {//if checkbox is not selected
					//isSelected will check if element is selected or not
					checkBox.click();
				}
			}else {
				if(checkBox.isSelected()) {
					checkBox.click();
				}
			}
		}
		//Checkbox is unchecked if you again click on it, means if we clicked on checked
		//checkbox then it will unchecked.
	}
}
/*
 * isDisplayed - check wether element is present or not
 * isEnabled - check weather element is clickable or not
 * isSelected - check wether element is selected or not
 * 
 * getText - return a string between ">" & "<". which is visible to user
 * getAttribute - return a attribute value of any specific attrbute name you mentioned
 */







