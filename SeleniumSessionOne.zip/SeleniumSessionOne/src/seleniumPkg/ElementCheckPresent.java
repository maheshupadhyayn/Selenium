package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElementCheckPresent {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_input_type_text");
		//Switch to frame for accessing all webelement under that frame
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		//Runtime HTML - DOM(Document Object Model)
		//Selenium search any webelement in DOM
		//Element is not present in DOM, do you think we can perform action? No
		//Reason to not present? HTML takes time to load, wrong element, JavaScript
		WebElement firstName = driver.findElement(By.id("fname"));
		if(firstName.isDisplayed()) {//it checks if element is present in DOM
			firstName.sendKeys("Omkar");
		}
	}
}
