package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElementGetText {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_button_test");
		//Switch to frame for accessing all webelement under that frame
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		//Action on button - click, double click, mouse hover, right click, gettext
		WebElement clickMe = driver.findElement(By.tagName("button"));
		if(clickMe.isDisplayed()) {
			if(clickMe.isEnabled()) {
				//text which is visible to end user is always kept in between ">" & "<"
				String buttonName = clickMe.getText();//getText will return a string, value between ">" & "<"
				if(buttonName.equals("Click Narendra!")) {
					clickMe.click();
				}else {
					System.out.println("Button is not having expected name");
				}
			}
		}
	}
}
