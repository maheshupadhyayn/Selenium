package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FrameImplementation {
	public static void main(String[] args) {
		/*
		 * Frame is a secure HTML component, which holds a webelements
		 * As a automation, we can't access any webelement from frame without switch to frame
		 */
		WebDriver driver  = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/frames.html");
		//1st way to switch frame - By Index
		driver.switchTo().frame(0);
		System.out.println(driver.findElement(By.tagName("h1")).getText());
		//2nd way to switch frame - By id/name as a String
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_input_type_text");
		driver.switchTo().frame("iframeResult");
		//3rd way to switch by WebElement
		WebElement frame = driver.findElement(By.id("iframeResult"));
		driver.switchTo().frame(frame);
		driver.switchTo().parentFrame();
	}
}
