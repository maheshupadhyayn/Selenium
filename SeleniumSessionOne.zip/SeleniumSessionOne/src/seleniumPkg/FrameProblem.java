package seleniumPkg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FrameProblem {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.citibank.com");
		//Step 1 - Login into application and check correct user login
		driver.findElement(By.id("user")).sendKeys("Ashok");
		driver.findElement(By.id("pass")).sendKeys("AshokGFName");
		driver.findElement(By.id("signin")).click();
		WebElement userName = driver.findElement(By.id("name"));
		if(userName.getText().equals("ASHOK")) {
			System.out.println("Step 1 is pass");
			//Step 2 - Check on Left navigation "Loan" link should present
			driver.switchTo().frame(1);//switch by index
			if(driver.findElement(By.linkText("Loan")).isDisplayed()) {
				System.out.println("Step 2 is pass");
				//Step 3 - Click on A/c Balance from quick links
				driver.switchTo().frame("rightFrame");//switch by String id/name
				if(driver.findElement(By.linkText("A/c Bal")).isDisplayed()) {
					driver.findElement(By.linkText("A/c Bal")).click();
					System.out.println("Step 3 is pass");
					//Step 4 - Check Balance is 10000.50 INR only
					WebElement centerFrame = driver.findElement(By.id("centerFrame"));
					driver.switchTo().frame(centerFrame);//switch by webelement
					if(driver.findElement(By.id("balance")).getText().equals("10000.50")) {
						System.out.println("Step 4 is pass");
						//Step 5 - to click on Logout button
						driver.switchTo().defaultContent();//switch to default frame
						if(driver.findElement(By.linkText("Logout")).isDisplayed()) {
							driver.findElement(By.linkText("Logout")).click();
							System.out.println("Step 5 is pass");
						}else {
							System.out.println("Step 5 is Fail");
						}
					}else {
						System.out.println("Step 4 is fail");
					}						
				}else {
					System.out.println("Step 3 is Fail");
				}
			}else {
				System.out.println("Step 2 is fail");
			}
		}else {
			System.out.println("Step 1 is fail");
		}
		
		
		WebElement pFrame = driver.findElement(By.id("parentFrame"));
		
		//1st Way to identify child frames
		List<WebElement> frames = pFrame.findElements(By.tagName("iframe"));
		for(WebElement frame:frames) {
			driver.switchTo().frame(frame);
		}
		
		//2nd Way to identify child frames
		WebElement lFrame = pFrame.findElement(By.id("leftFrame"));
		driver.switchTo().frame(lFrame);
		if(driver.findElement(By.linkText("Loan")).isDisplayed()) {
			System.out.println("Step 2 is pass");
		}
		//Switch back to Parent frame
		driver.switchTo().parentFrame();//Switch to parent frame
		
	}
}
