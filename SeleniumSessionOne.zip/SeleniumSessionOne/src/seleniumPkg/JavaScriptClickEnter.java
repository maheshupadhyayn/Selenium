package seleniumPkg;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptClickEnter {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		
		//We want to make Javascript as a driver
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		Thread.sleep(3000);
		//Set the value to the textbox using javascript
		js.executeScript("document.getElementById('fname').value='Omkar';");
		//Click on element
		js.executeScript("document.getElementById('submitbtn').click();");
	}
}
