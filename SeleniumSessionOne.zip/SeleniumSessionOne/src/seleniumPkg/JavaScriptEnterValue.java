package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptEnterValue {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		
		//We want to make Javascript as a driver
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//Set the value to the textbox using javascript
		js.executeScript("document.getElementById('fname').value='Omkar';");
	}
}
