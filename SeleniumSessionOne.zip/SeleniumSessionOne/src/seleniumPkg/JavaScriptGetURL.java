package seleniumPkg;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptGetURL {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		Thread.sleep(5000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('fname').value='Omkar';");
		//Click on element
		js.executeScript("document.getElementById('submitbtn').click();");
		//Get Current domain
		String domain =js.executeScript("return document.domain;").toString();
		System.out.println(domain);
		//Get Current URL
		String url =js.executeScript("return document.URL;").toString();
		System.out.println(url);
	}
}
