package seleniumPkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class KeyboardOperation {
	
	public static void main(String[] args) throws InterruptedException {
			WebDriver driver = new ChromeDriver();
			driver.get("https://nursingdemo.medifox.in.net/Account/Login");
			Thread.sleep(3000);
			Actions act = new Actions(driver);
			Action action = act.sendKeys(Keys.TAB)
				.sendKeys("admin")
				.sendKeys(Keys.TAB)
				.sendKeys("admin")
				.pause(Duration.ofSeconds(2000))
				.sendKeys(Keys.TAB)
				.sendKeys(Keys.ENTER)
				.build();
				
			action.perform();
			//Series of actions
		/*
		 * Actions is a class - used for single action
		 * Action is interface - used for series of action
		 * 
		 * Actions class implements action
		 */
	}
}
