package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class KeyboardScroll {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qapenguin.com");
		WebElement link = driver.findElement(By.linkText("Financial Projections"));
		Thread.sleep(3000);
		Actions act = new Actions(driver);
		for(int i=0; i<=5; i++) {
			Thread.sleep(1000);
			act.sendKeys(Keys.PAGE_DOWN).build().perform();
		}
		for(int i=0; i<=5; i++) {
			Thread.sleep(1000);
			act.sendKeys(Keys.PAGE_UP).build().perform();
		}
	}
}
