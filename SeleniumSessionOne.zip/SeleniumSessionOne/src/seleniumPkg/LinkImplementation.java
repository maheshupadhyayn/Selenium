package seleniumPkg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LinkImplementation {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/html/tryit.asp?filename=tryhtml_links_w3schools");
		//Switch to frame for accessing all webelement under that frame
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		WebElement link = driver.findElement(By.tagName("a"));
		if(link.getText().equals("Visit W3Schools.com!")) {
			link.click();
		}
		Thread.sleep(3000);
		List<WebElement> links = driver.findElements(By.className("ga-nav"));
		for(WebElement li:links) {
			if(li.getText().equals("CSS")) {
				System.out.println(li.getAttribute("href"));
				li.click();
			}
		}
		
	}
}
