package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseDoubleClick {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_ev_ondblclick");
		Thread.sleep(3000);
		driver.switchTo().frame("iframeResult");
		WebElement loginBtn = driver.findElement(By.tagName("button"));
		Actions act = new Actions(driver);
		act.click(loginBtn).build().perform();
		Thread.sleep(3000);
		act.doubleClick(loginBtn).build().perform();
	}
}
