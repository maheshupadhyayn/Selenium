package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseDragandDrop {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://testpages.herokuapp.com/styled/drag-drop-javascript.html");
		Thread.sleep(3000);
		WebElement source1 = driver.findElement(By.id("draggable1"));
		WebElement target1 = driver.findElement(By.id("droppable1"));
		Actions act = new Actions(driver);
		act.dragAndDrop(source1, target1).build().perform();
		Thread.sleep(3000);
		WebElement source2 = driver.findElement(By.id("draggable2"));
		WebElement target2 = driver.findElement(By.id("droppable2"));
		act.dragAndDrop(source2, target2).build().perform();
	}
}
