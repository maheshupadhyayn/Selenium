package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseScroll {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.qapenguin.com");
		WebElement link = driver.findElement(By.linkText("Financial Projections"));
		Thread.sleep(3000);
		Actions act = new Actions(driver);
		//act.scrollToElement(link).build().perform();
		for(int i=0;i<=10;i++) {
			Thread.sleep(1000);
			act.scrollByAmount(0, 350).build().perform();
		}
	}
	
}
