package seleniumPkg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MultiDropdown {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_select_multiple");
		//Switch to frame for accessing all webelement under that frame
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		WebElement drpDwn = driver.findElement(By.name("cars"));
		//Can we access all childs with the help of parent? - Yes
		List<WebElement> options = drpDwn.findElements(By.tagName("option"));
		for(WebElement option:options) {
			//System.out.println(option.getText());
			Thread.sleep(1000);
			option.click();
		}
		/*
		Thread.sleep(2000);
		//I want to get all selected option from list
		Select opts = new Select(drpDwn);
		List<WebElement> selectedOptions = opts.getAllSelectedOptions();
		for(WebElement option:selectedOptions) {
			System.out.println(option.getText());
		}
		
		Thread.sleep(2000);
		//I want to deselect all options
		opts.deselectAll();
		Thread.sleep(2000);
		opts.selectByVisibleText("Audi");
		Thread.sleep(1000);
		opts.selectByValue("volvo");
		// I want to get first selected option
		WebElement firstOpt = opts.getFirstSelectedOption();
		System.out.println(firstOpt.getText());
		opts.deselectAll();
		//I f i want to get all options from dropdown, i want to know how many options
		List<WebElement> os =  opts.getOptions();
		for(WebElement o:os) {
			if(o.getText().equals("Opel") || o.getText().equals("Saab")) {
				o.click();
			}
		}*/
	}
	/*
	 * Select by index
	 * SelectByVisibleText
	 * SelectByValue
	 * DeselectByIndex
	 * DeselectByValue
	 * DeselectByVisibleText
	 * DeseltAll
	 * GettAllSelectedOptions
	 * GetFirstSelecredOption
	 * GetOptions
	 */
}
