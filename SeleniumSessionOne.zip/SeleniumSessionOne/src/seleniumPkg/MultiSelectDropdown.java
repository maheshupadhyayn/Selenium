package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class MultiSelectDropdown {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_select_multiple");
		//Switch to frame for accessing all webelement under that frame
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		WebElement drpDwn = driver.findElement(By.name("cars"));
		//If you want to select a drop down then I have a class name as Select in selenium
		Select option = new Select(drpDwn);
		//Select by visible text
		Thread.sleep(3000);
		option.selectByVisibleText("Audi");
		//Select by value
		Thread.sleep(3000);
		option.selectByValue("saab");
		//Select by Index
		Thread.sleep(3000);
		option.selectByIndex(2);
		//Deselect by visible Text
		Thread.sleep(3000);
		option.deselectByVisibleText("Audi");
		//DeSelect by Index
		Thread.sleep(3000);
		option.deselectByIndex(0);//If option is not selected then it won't perform any action
		//DeSelect by Value
		Thread.sleep(3000);
		option.selectByValue("saab");
	
	}
}
