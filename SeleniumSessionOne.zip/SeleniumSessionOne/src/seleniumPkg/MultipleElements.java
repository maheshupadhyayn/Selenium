package seleniumPkg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultipleElements {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/final.html");
		
		WebElement ele = driver.findElement(By.xpath("//input[@type='text']"));
		//ele.sendKeys("Sharvari");
		
		List<WebElement> textBoxes = driver.findElements(By.xpath("//input[@type='text']"));
		
		for(WebElement textBox : textBoxes) {
			Thread.sleep(2000);
			textBox.sendKeys("Priyanka");
		}
		
		/*
		 * List is a type of collection, which maintains the order
		 * We define type of list within <dataType>
		 */
		
		/*
		 * Difference between findElement() & findElements()
		 * 
		 * findElement returns a single webelement
		 * findelements returns a list of webelement
		 */
	}
}




