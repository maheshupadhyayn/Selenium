package seleniumPkg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Navigation;
import org.openqa.selenium.chrome.ChromeDriver;

public class NavigateToURL {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver  = new ChromeDriver();
		driver.get("https://www.google.co.in/");
		//Hard stop for 3 secs
		Thread.sleep(3000);
		driver.navigate().to("https://www.knowledgeware.in/final.html");
		Thread.sleep(3000);
		//enter user name
		/*
		 * get() - will wait until your complete page loads
		 * navigate.to() - will not wait till complete page loads
		 */
		driver.navigate().back();//google
		Thread.sleep(3000);
		driver.navigate().forward();//knowledgeware
		Thread.sleep(3000);
		driver.navigate().refresh();//knowledgeware refresh
		
		Navigation n = driver.navigate();
		n.to("url");
		
		int age = add();
	}
	
	public static int add() {
		return 10;
	}
}








