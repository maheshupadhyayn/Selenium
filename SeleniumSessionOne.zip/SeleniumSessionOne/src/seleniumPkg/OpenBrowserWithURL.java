package seleniumPkg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenBrowserWithURL {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		//Driver is nothing but an browser for me, in this case it is Chrome
		//Enter url into address bar of chrome and press enter
		//driver.get("https://www.google.co.in/");
		//get() is a method which will help you to enter url into address bar & press enter
		driver.get("https://www.knowledgeware.in/final.html");
	}
}
