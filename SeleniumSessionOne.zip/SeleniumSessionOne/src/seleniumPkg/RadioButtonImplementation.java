package seleniumPkg;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RadioButtonImplementation {
	public static void main(String[] args) throws InterruptedException {
		//Radio button allows you a single selection at one time
		//checkbox allows you multi options selection
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_input_type_radio");
		//Switch to frame for accessing all webelement under that frame
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		//- //tagname[@attrName ='attrVal']
		List<WebElement> radioBtns = driver.findElements(By.xpath("//input[@type='radio']"));
		for(WebElement radioBtn : radioBtns) {
			String vehicleName = radioBtn.getAttribute("value");
			if(vehicleName.equals("HTML") || vehicleName.equals("60")) {
				radioBtn.click();
			}
		}
	}
	
}
