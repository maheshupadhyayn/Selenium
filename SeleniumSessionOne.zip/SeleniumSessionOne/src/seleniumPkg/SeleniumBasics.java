package seleniumPkg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class SeleniumBasics {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();//It opens a blank chrome window, without url
		/* What is WebDriver?
		 * Ans - WebDriver is an interface, and it's method are overridden within respective
		 * 		classes
		 * 
		 * What is ChromeDriver?
		 * Ans - Is a class which implements all abstract method from webdriver
		 */
		//WebDriver d1 = new WebDriver();//Interface can't instatiate/object
		//ChromeDriver driver1 = new ChromeDriver();//Valid
		//driver = new EdgeDriver();//Re-assignment
		//driver1 = new EdgeDriver();//Invalid
		
	}
	/*
	 * What is Selenium?
	 * A - Selenium which automates browser
	 * 
	 * What is Browser? (Chrome, Edge, Safari, Opera, IE, Mozilla)
	 * A - It's a client to communicate web application
	 * 
	 * What is Web Application?
	 * A - To acheive any task online - Medium to communicate any particular software/service
	 * 	   It is a combination of web Pages
	 * 
	 * How this web application build?
	 * A - It is build by HTML (Hypertext Markup Language)
	 * 
	 * What is HTML?
	 * A - Which helps to build web pages, & it's a scripting language
	 * 
	 * What is Web Page?
	 * A - It is a combination of WebElements (TextBox, Button, Link, dropdown)
	 * 
	 * What is WebElement?
	 * A - It is a combination of html tags and attributes
	 *  
	 * How to check HTML Tags & Attributes?
	 * A - 1st way - Right click Anywhere -> Inspect -> It opens Dev Tool
	 * 	   2nd way - F12 OR if function key is activated then "fn + F12" - it open dev tool
	 * 
	 * How do i identify a specific webelement's tag and attribute?
	 * A - 1st way - Right Click on WebElement -> Inspect
	 * 	   2nd way - Click on "<-" arrow from dev tool->Click on any weblement
	 * 
	 * How do i get/copy Tags and attribute for specific webelement?
	 * A - right click on highligted row->copy->copy outerHTML
	 *     userName - <input type="text" name="name">
	 *     password - <input type="text" name="password" value="">
	 *     login - <a style="color:#28d7d8;" href="reg.html">LOGIN</a>
	 *     Google Search Box - <textarea class="gLFyf" aria-controls="Alh6id" aria-owns="Alh6id" autofocus="" 
		 *     title="Search" value="" jsaction="paste:puy29d;" aria-label="Search" 
		 *     aria-autocomplete="both" aria-expanded="false" aria-haspopup="false" 
		 *     autocapitalize="off" autocomplete="off" autocorrect="off" id="APjFqb" 
		 *     maxlength="2048" name="q" role="combobox" rows="1" spellcheck="false" 
		 *     data-ved="0ahUKEwjsw7S-7PeEAxU9l1YBHedPA5cQ39UDCAw"></textarea>
	 *     
	 * What is Tag?
	 * A - Tag always starts immediate after "<" , it's scope ends ">"
	 * 
	 * What is Attribute?
	 * A - Additional information/uniqueness to any specific webelement
	 * 	   Following after tag, it is always a attribute
	 * 	   Syntax <tagname attrbute1="attrValue" attrbute2="attrValue2">
	 * 
	 * How do we identify WebElement?
	 * A - By unique Locators
	 * 
	 * What is Locator?
	 * A - Way of identification/identifier/unique
	 * 
	 * How many locators?
	 * A - There are 8 locators in selenium
	 * 		1 - ID
	 * 		2 - Name
	 * 		3 - LinkText
	 * 		4 - PartialLinkText
	 * 		5 - TagName
	 * 		6 - ClassName
	 * 		7 - XPath
	 * 		8 - CSS Selector
	 * 	Locator will help you to identify unique webelement from the web page
	 */
}






