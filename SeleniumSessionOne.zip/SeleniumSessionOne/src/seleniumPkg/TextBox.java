package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TextBox {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml5_input_type_text");
		//Switch to frame for accessing all webelement under that frame
		driver.switchTo().frame("iframeResult");
		
		driver.findElement(By.id("fname")).sendKeys("Ashok");
		Thread.sleep(3000);
		driver.findElement(By.tagName("input")).sendKeys("Kamthe");//It enters last name on 
		//the first input tag it identifies
		
		/* We were not able to find because it has a implementation of frame
		 * What is frame?
		 * A - Frame is secure HTML component, without frame permission you can not access any 
		 *     element from that frame by automation tool
		 * 
		 * How do we identify a element within frame?
		 * A - We need to switch to that frame before accessing any webelement.
		*/
		
		/*
		 * Basic XPath
		 * What is XPath?
		 * A - It is extended XML path, which will build with the help of attributes and tag
		 * 
		 * Syntax of XPath - 
		 * //*[@id="fname"] - Relative Xpath - Middle of your HTML
		 * /html/body/form/input[1] - Absolute XPath - full path from root
		 * 
		 * Syntax of xpath
		 * -//tagname[@attributeName="attributeValue"]
		 * 
		 * Xpath where to write?
		 * A - we can write in console of dev tools
		 * 
		 * How do we write xpath in console?
		 * A - $x("syntax")
		 * 
		 * /html/body/div/div/form/input[1]
		 */
	}
}






