package seleniumPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TextBoxEnter {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/final.html");
		//Enter a username sonal on User field
		//findElement() is a method available in webdriver interface, whichelps too
		//find a unique webelement. It returns you a single webelement
		WebElement userName = driver.findElement(By.name("name"));
		//Action on webelement
		userName.sendKeys("Sonal");
		Thread.sleep(3000);
		WebElement password = driver.findElement(By.name("password"));
		password.sendKeys("Omkar");
		Thread.sleep(3000);
		driver.findElement(By.name("confirmpassword")).sendKeys("Sonu");
		//CLick function is use to click on any webelement
		Thread.sleep(3000);
		driver.findElement(By.linkText("LOGIN")).click();
		
	}
}
