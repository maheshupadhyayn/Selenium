package seleniumPkg;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class WindowClose {
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.yahoo.com");
		
		Thread.sleep(3000);
		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.get("https://www.google.co.in");

		Thread.sleep(3000);
		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.get("https://money.rediff.com/index.html");
		
		Thread.sleep(3000);
		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.get("https://www.amazon.co.in");
		
		//System.out.println(12/0);
		
		Thread.sleep(2000);
		//driver.close();//Close is a method, which will close last window open by current driver
		driver.quit();//Quit is a method, which will close all open windows by current driver
	}
}
