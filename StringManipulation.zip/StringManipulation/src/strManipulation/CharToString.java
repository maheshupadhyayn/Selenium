package strManipulation;

public class CharToString {

	public static void main(String[] args) {
		
		char[] charArray = {'J', 'A', 'V', 'A' };
		
		String text = new String(charArray);
		
		System.out.println(text);
		
		//How to convert character array into an String
		
	}
}
