package strManipulation;

public class ContainsString {
	public static void main(String[] args) {
		String s = "I am a tech architect in infy.";
		System.out.println(s.contains("tech architect"));
		
		String s1 = "selenium";
		System.out.println(s1.contains("len"));
		
		System.out.println(s1.contains("Nium"));
		
		String s2 = "Your Transaction ID 45678902 submitted succesfully.";
	}
}
