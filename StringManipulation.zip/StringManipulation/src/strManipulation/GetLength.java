package strManipulation;

public class GetLength {

	public static void main(String[] args) {
			
		String text = "automatedScript ";
		int l = text.length();
	    
	    //length() is a method, which will return you the number of characters in a string
		System.out.println(l);
		System.out.println(text.length());
	}
}
