package strManipulation;

public class StringClass {

	public static void main(String[] args) {
		// String declRrion
		String str = "hello";
		String str1 = "Selenium";
		int a = 10;
		int b = 20;
		System.out.println(str+str1+a+b);
		System.out.println(a+b+str+str1);
	}

}
