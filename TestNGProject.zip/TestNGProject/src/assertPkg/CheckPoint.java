package assertPkg;

import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckPoint {
	/*
	 * What is Assertion?
	 * To check, Verify - Checkpoint(Pass, Fail)
	 * 
	 * If assertion failed, it terminates your execution
	 */
	@Test
	public void TC1() {
		Assert.assertEquals(true, false);
	}
	@Test
	public void TC2() {
		Assert.assertEquals(true, true);
	}
	@Test
	public void TC3() {
		Assert.assertEquals("Selenium", "SeLenium");
	}
	@Test
	public void TC4() {
		Assert.assertEquals(20, 200);
	}
	@Test
	public void TC5() {
		Assert.assertEquals(100.1, 100.01);
	}
	@Test
	public void TC6() {
		Assert.assertEquals("A", 'A');
	}
}
