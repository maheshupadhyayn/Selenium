package assertPkg;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckPointDifferent {
	@Test
	public void TC1() {
		Assert.assertEquals(false, false);
	}
	
	@Test
	public void TC2() {
		Assert.assertNotEquals(false, true);
	}
	
	@Test
	public void TC3() {
		Assert.assertNotEquals("true", true);
	}
	
	@Test
	public void TC4() {
		boolean expected = false;
		Assert.assertTrue(true, "Test is expected pass");
	}
	
	@Test
	public void TC5() {
		boolean expected = false;
		Assert.assertFalse(expected);
	}
	
	@Test
	public void TC6() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		boolean answer = driver.getTitle().equals("Elements - Tools Text Box");
		Assert.assertTrue(answer, "Test is expected pass");
	}
}
