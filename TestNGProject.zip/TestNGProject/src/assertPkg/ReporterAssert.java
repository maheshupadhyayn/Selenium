package assertPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class ReporterAssert {
	@Test
	public void formSubmit() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		Assert.assertEquals("Elements - Tools Text Box", driver.getTitle());
		WebElement fName = driver.findElement(By.id("fname"));
		fName.sendKeys("Gopal");
		Assert.assertEquals("Full Name", fName.getAttribute("placeholder"));
		WebElement submit = driver.findElement(By.id("submitbtn"));
		Assert.assertEquals("Submit", submit.getText());
		
	}
}
