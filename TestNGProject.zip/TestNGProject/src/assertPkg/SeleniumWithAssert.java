package assertPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class SeleniumWithAssert {
	@Test
	public void formSubmit() {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		Assert.assertEquals("Elements - Toolsss Text Box", driver.getTitle());
		driver.findElement(By.id("fname")).sendKeys("Gopal");
		driver.findElement(By.id("mailid")).sendKeys("Gopal@gmail.com");
	}
}
