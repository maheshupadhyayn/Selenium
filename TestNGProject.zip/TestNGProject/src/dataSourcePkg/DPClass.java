package dataSourcePkg;

import org.testng.annotations.DataProvider;

public class DPClass {
	 @DataProvider(name = "LoginDP")
	  public Object[][] login() {
	    return new Object[][] {
	      new Object[] { "user", "Sharvari" },
	      new Object[] { "user1", "Narendra" },
	      new Object[] { "user2", "Sonu" },
	      new Object[] { "user3", "Sonali" },
	    };
	  }
	 @DataProvider(name = "RegistrationDP")
	  public Object[][] registration() {
	    return new Object[][] {
	      new Object[] { "Akshata", "Kadam", "ea@a.com" },
	      new Object[] { "Kartik", "Surve", "ek@a.com" },
	      new Object[] { "Shruti", "Shah", "es@a.com" },
	    };
	  }
	 @DataProvider(name = "OutboxDP")
	  public Object[][] outbox() {
	    return new Object[][] {
	      new Object[] { 12},
	      new Object[] { 23},
	      new Object[] { 29},
	      new Object[] { 150},
	    };
	  }
}
