package dataSourcePkg;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class DataProviderSample {
  @Test(dataProvider = "dp", invocationCount = 2, enabled = false)
  public void TC1(Integer rollNo, String name) {
	  System.out.println("My roll no is - "+rollNo+" & my name is "+name);
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { 123, "Sharvari" },
      new Object[] { 234, "Narendra" },
    };
  }
  /*
   * dp() method is a data source for me
   * Always Data Provider returns a two dim object array
   * How many rows - 2 rows
   * The number rows the number of times TC will execute
   */
}
