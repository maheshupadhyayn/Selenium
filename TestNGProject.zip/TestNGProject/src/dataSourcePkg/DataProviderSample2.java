package dataSourcePkg;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class DataProviderSample2 {
  @Test(dataProvider = "LoginDP")
  public void TC1(Integer rollNo, String name) {
	  System.out.println("My roll no is - "+rollNo+" & my name is "+name);
  }

  @DataProvider(name = "LoginDP")
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { 123, "Sharvari" },
      new Object[] { 234, "Narendra" },
    };
  }
}
