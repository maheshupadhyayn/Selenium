package dataSourcePkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderWithSelenium {
	@Test(dataProvider = "dp")
	  public void TC1(String locator, String fName, String email) {
		WebDriver driver  = new ChromeDriver();
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		driver.findElement(By.id(locator)).sendKeys(fName);
		driver.findElement(By.id(locator)).sendKeys(email);
	  }

	  @DataProvider
	  public Object[][] dp() {
	    return new Object[][] {
	      new Object[] { "fname","Kartik Surve", "kartik@gmail.com" },
	      new Object[] { "mailid","Shruti Shah", "shrithi@gmail.com" },
	    };
	  }
}
