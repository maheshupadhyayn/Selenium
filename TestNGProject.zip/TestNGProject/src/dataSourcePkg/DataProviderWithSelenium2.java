package dataSourcePkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderWithSelenium2 {
	@Test(dataProvider = "dp")
	  public void TC1(String url, String byWhat, String locator, String name) {
		WebDriver driver  = new ChromeDriver();
		driver.get(url);
		driver.findElement(findby(byWhat, locator)).sendKeys(name);
	  }

	  @DataProvider
	  public Object[][] dp() {
	    return new Object[][] {
	      new Object[] { "https://www.knowledgeware.in/Automation/index.html","id","fname","Sonu"},
	      new Object[] { "https://www.google.co.in","name","q","Narendra"},
	    };
	  }
	  
	  public static By findby(String byWhat, String locator) {
		  By by = null;
		  switch (byWhat) {
			case "id": 
				by = By.id(locator);
				break;
			case "name": 
				by = By.name(locator);
				break;
			case "xpath":
				by = By.xpath(locator);
				break;
		  }
		return by;
	  }
}
