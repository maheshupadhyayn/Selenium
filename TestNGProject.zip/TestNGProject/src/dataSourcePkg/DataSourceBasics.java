package dataSourcePkg;

public class DataSourceBasics {
/*
 * What is data source?
 * Ans - From where we access our Test Data (Which use for test execution)
 * 
 * Which are the data sources you heard?
 * Ans -1 - Data base(DB)
 * 		2 - CSV
 * 		3 - Excel
 * 		4 - XML
 * 		5 - JSON
 * 		6 - Notepad
 * 		7 - Word
 * 		8 - Properties
 * 		9 - Data Provider
 * 		10 - Data Parameters 
 */
}
