package dataSourcePkg;

import org.testng.annotations.Test;

public class TestClass extends DPClass{
	@Test(dataProvider = "LoginDP")
	public void loginTest(String user, String pass) {
		
	}
	@Test(dataProvider = "RegistrationDP")
	public void registrationTest(String fName, String lName, String email) {
		
	}
	@Test(dataProvider = "OutboxDP")
	public void outboxTest(Integer numEmail) {
		
	}
}
