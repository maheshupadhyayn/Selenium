package multipleSuitePkg;

import org.testng.annotations.Test;

public class Compose {
	@Test(groups = {"outbox","drafts"})
	public void composeTC1() {}
	
	@Test
	public void composeTC2() {}
	
	@Test
	public void composeTC3() {}
	
	@Test
	public void composeTC4() {}
	
	@Test(groups = "outbox")
	public void composeTC5() {}
	
	@Test(groups = {"outbox","drafts"})
	public void composeTC6() {}

}
