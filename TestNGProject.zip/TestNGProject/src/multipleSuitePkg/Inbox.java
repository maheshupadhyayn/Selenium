package multipleSuitePkg;

import org.testng.annotations.Test;

public class Inbox {
	@Test
	public void inboxTC1() {}
	
	@Test(groups = {"outbox","drafts"})
	public void inboxTC2() {}
	
	@Test(groups = "outbox")
	public void inboxTC3() {}
	
	@Test(groups = {"drafts"})
	public void inboxTC4() {}
}
/*
 * There is a new feature launch "outbox"
 * 	inbox=20- TC
 * 	Compose=30
 * 	Sent=30
 */
