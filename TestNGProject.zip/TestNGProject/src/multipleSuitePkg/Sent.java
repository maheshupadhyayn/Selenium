package multipleSuitePkg;

import org.testng.annotations.Test;

public class Sent {
	@Test
	public void sentTC1() {}
	
	@Test(groups = {"outbox", "drafts"})
	public void sentTC2() {}
	
	@Test
	public void sentTC3() {}
	
	@Test(groups = "outbox")
	public void sentTC4() {}
	
	@Test(groups = "outbox")
	public void sentTC5() {}
	
	@Test
	public void sentTC6() {}
}
