package parameterPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParameterClass {
  @Parameters({"user","email"})
  @Test()
  public void TC1(String u, String e) {
	WebDriver driver  = new ChromeDriver();
	driver.get("https://www.knowledgeware.in/Automation/index.html");
	driver.findElement(By.id("fname")).sendKeys(u);
	driver.findElement(By.id("mailid")).sendKeys(e);
  }
  
  @Parameters({"email"})
  @Test()
  public void TC2(String e) {
	WebDriver driver  = new ChromeDriver();
	driver.get("https://www.knowledgeware.in/Automation/index.html");
	driver.findElement(By.id("mailid")).sendKeys(e);
  }
}
