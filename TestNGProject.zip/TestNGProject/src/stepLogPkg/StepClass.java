package stepLogPkg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class StepClass {
	@Test
	public void formSubmit() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		Reporter.log("I have succesfully open Chrome Browser");
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		Reporter.log("I have succesfully open Registration form");
		driver.findElement(By.id("fname")).sendKeys("Gopal");
		Reporter.log("I have succesfully enter user first name");
		driver.findElement(By.id("mailid")).sendKeys("Gopal@gmail.com");
		Reporter.log("I have succesfully user email id");
		Thread.sleep(2000);
		Reporter.log("I have succesfully close Chrome Browser");
		//driver.close();
	}
	@Test
	public void login() throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		Reporter.log("I have succesfully open Chrome Browser");
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		Reporter.log("I have succesfully open Registration form");
		driver.findElement(By.id("fname")).sendKeys("Gopal");
		Reporter.log("I have succesfully enter user first name");
		driver.findElement(By.id("mailid")).sendKeys("Gopal@gmail.com");
		Reporter.log("I have succesfully user email id");
		Thread.sleep(2000);
		Reporter.log("I have succesfully close Chrome Browser");
		//driver.close();
	}
	
	@Test
	public void exceptionTest() {
		try {
			WebDriver driver = new ChromeDriver();
			Reporter.log("I have succesfully open Chrome Browser");
			driver.get("https://www.knowledgeware.in/Automation/index.html");
			Reporter.log("I have succesfully open Registration form");
			driver.findElement(By.id("fname")).sendKeys("Gopal");
			Reporter.log("I have succesfully enter user first name");
			driver.findElement(By.id("abcde")).sendKeys("Gopal@gmail.com");
			Reporter.log("I have succesfully user email id");
			Reporter.log("I have succesfully close Chrome Browser");
		} catch (Exception e) {
			Reporter.log("I got an exception: - "+e.getMessage().toString().substring(0, 100));
		}
		//driver.close();
	}
}
