package synchronizationPkg;

public class BasicSync {
/*
 * Wait?
 * Ans - Asking forcefully or logically java program to wait/to pause execution
 * 
 * How many types of wait in selenium?
 * Ans - There are 2 types of wait
 * 		1 - Unconditional
 * 			a - thread.sleep(3000);
 * 			b - wait(3);
 * 		2 - Conditional
 * 			a - Implicitly Wait
 * 			b - Explicit Wait
 * 			c - Fluent Wait
 */
}
