package synchronizationPkg;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ExplicitWait {
	//Explicit wait will work for individual element
	WebDriver driver = null;
	@BeforeMethod
	public void beforeEachTest() {
		driver = new ChromeDriver();
	}
	@Test
	public void TC6() {
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		driver.findElement(By.id("fname")).sendKeys("Narendra");
		//Explicit wait implementation
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		WebElement email = wait.until(ExpectedConditions.elementToBeClickable(By.id("mailid")));
		
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());
		
		By by = By.id("iframeResults");
		
		wait.until(ExpectedConditions.attributeContains(by, "name", "abc"));
		boolean b = wait.until(ExpectedConditions.elementToBeSelected(by));
		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(by));
		
		email.sendKeys("a@a.com");
	}
	@Test
	public void TC2() {
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		driver.findElement(By.id("fname")).sendKeys("Narendra");
		//Explicit wait implementation
		WebElement fName = WebElementCommon.isClickable(driver, By.id("fname"));
		WebElement email = WebElementCommon.isClickable(driver, By.id("mailid"));
		email.sendKeys("a@a.com");
	}
	@AfterMethod
	public void afterEachTest() {
		driver.close();
	}
	
	
}
