package synchronizationPkg;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class ImplicitWait {
	WebDriver driver = null;
	@BeforeMethod
	public void beforeEachTest() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
	}
	@Test
	public void TC6() {
		driver.get("https://www.knowledgeware.in/Automation/index.html");
		driver.findElement(By.id("fname")).sendKeys("Narendra");
		driver.findElement(By.id("mailiddfdsjs")).sendKeys("a@a.com");
		driver.findElements(By.tagName("inputfd"));
		
		driver.getTitle();//No implict wait
		driver.getCurrentUrl();//No
		driver.get("");//no
	}
	@AfterMethod
	public void afterEachTest() {
		driver.close();
	}
	/*
	 * 1 -Implicit wait will define immediately after driver initialize
	 * 2 - That means scope of implicit wait will work until your driver is close/kill
	 * 3 - Implicit wait will work only on 2 commands - findelement & findelements
	 * 4 - 
	 */
}









