package testNGAttributes;

import org.testng.annotations.Test;

public class AlwaysExecute {
	@Test()
	public void signIn() {}
	
	@Test(alwaysRun = true, dependsOnMethods = {"compose"})
	public void inbox() {}
	
	@Test(dependsOnMethods = "signIn")
	public void compose() {System.out.println(10/0);}
	
	@Test(dependsOnMethods = "inbox")
	public void logout() {}
}
