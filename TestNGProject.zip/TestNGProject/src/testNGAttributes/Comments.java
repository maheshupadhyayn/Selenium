package testNGAttributes;

import org.testng.annotations.Test;

public class Comments {
	@Test(description = "As a user, I want to login into knowledgeware site")
	public void TC1() {
		System.out.println("In TC1");
	}
	@Test(description = "As a user, I want to logout from Knowledgeware Site")
	public void TC2() {
		System.out.println("In TC2");
	}
}
/*
I have an attribute which will give you a detail description of your test
Always attributes work with @Test annotation
*/