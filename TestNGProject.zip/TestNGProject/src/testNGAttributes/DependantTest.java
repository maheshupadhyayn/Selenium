package testNGAttributes;

import org.testng.annotations.Test;

public class DependantTest {
	@Test()
	public void signIn() {}
	
	@Test(dependsOnMethods = {"compose", "signIn"})
	public void inbox() {}
	
	@Test(dependsOnMethods = "signIn")
	public void compose() {}
	
	@Test(dependsOnMethods = "inbox")
	public void logout() {}
}
