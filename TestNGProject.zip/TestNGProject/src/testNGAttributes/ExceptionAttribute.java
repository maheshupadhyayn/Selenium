package testNGAttributes;

import org.testng.annotations.Test;

public class ExceptionAttribute {
	@Test
	public void TC1() {}
	
	@Test(expectedExceptions = ArithmeticException.class)
	public void TC2() {
		System.out.println(10/0);
	}
	
	
}
