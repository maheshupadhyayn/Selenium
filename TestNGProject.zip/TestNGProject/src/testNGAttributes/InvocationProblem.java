package testNGAttributes;

import org.testng.annotations.Test;

public class InvocationProblem {
	@Test(invocationCount = 10)
	public void login() {
	
	}
	@Test(invocationCount = 2, priority = 0)
	public void inbox() {
		
	}
	@Test(priority = 1)
	public void logout() {
		
	}
}
