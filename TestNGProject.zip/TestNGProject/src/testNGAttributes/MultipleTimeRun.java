package testNGAttributes;

import org.testng.annotations.Test;

public class MultipleTimeRun {
	@Test(invocationCount = 10)
	public void login() {
		System.out.println("I am logged in");
	}
}
