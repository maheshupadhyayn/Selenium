package testNGAttributes;

import org.testng.annotations.Test;

public class PriorityQuestion1 {
	@Test(priority = 0)
	public void signIn() {
		System.out.println("In TC1");
	}
	@Test(priority = -22)
	public void inbox() {
		System.out.println("In TC2");
	}
	@Test(priority = -300)
	public void compose() {
		System.out.println("In TC3");
	}
	@Test(priority = 4)
	public void logout() {
		System.out.println("In TC4");
	}
	//Can we give negative priority - yes
}
