package testNGAttributes;

import org.testng.annotations.Test;

public class PriorityQuestion2 {
	@Test(priority = -2)
	public void TC1() {}
	
	@Test(priority = 11)
	public void TC2() {}
	
	@Test
	public void TC3() {}
	
	@Test(priority = 0)
	public void TC4() {}
	
	@Test(priority = 7)
	public void TC5() {}
	
	@Test(priority = 3)
	public void TC6() {}
	
	@Test(priority = 7)
	public void TC7() {}
	//If priority is not defined, testNG has default priority = 0
}
