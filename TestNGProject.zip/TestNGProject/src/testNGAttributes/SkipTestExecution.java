package testNGAttributes;

import org.testng.annotations.Test;

public class SkipTestExecution {
	@Test
	public void TC1() {}
	
	@Test(enabled = false, priority = 1)
	public void TC2() {}
	
	@Test
	public void TC3() {}
	
	@Test
	public void TC4() {}
}
