package testNGAttributes;

import org.testng.annotations.Test;

public class TestExecutionPriority {
	@Test(description = "As a user, I want to login into knowledgeware site", priority = 1)
	public void signIn() {
		System.out.println("In TC1");
	}
	@Test(description = "As a user, I want to check my email", priority = 2)
	public void inbox() {
		System.out.println("In TC2");
	}
	@Test(description = "As a user, I want to sent an email", priority = 3)
	public void compose() {
		System.out.println("In TC3");
	}
	@Test(description = "As a user, I want to logout from Knowledgeware Site", priority = 4)
	public void logout() {
		System.out.println("In TC4");
	}
	//TestNG execute test on alphabetical order
	//We can give multiple attribute by comma separated
}
