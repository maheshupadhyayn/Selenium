package testNGAttributes;

import org.testng.annotations.Test;

public class TimeoutAfterSomeTime {
	@Test
	public void TC1() {}
	
	@Test(enabled = false, priority = 1)
	public void TC2() {}
	
	@Test(timeOut = 1000)
	public void TC3() throws InterruptedException {
		Thread.sleep(2000);
	}
	
	@Test
	public void TC4() {}
}
