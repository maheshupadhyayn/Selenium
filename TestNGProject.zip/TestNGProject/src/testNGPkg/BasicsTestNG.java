package testNGPkg;

public class BasicsTestNG {
/*
 * What is TestNG?
 * ANs - TestNG is a framework.
 * Testing Next Generation Framework
 * 
 * What is Unit Testing
 * Developer perform test around his developed code
 * JUnit - Java Unit Test Framework
 * 
 * Why TestNG?
 * 1 - To Remove main method
 * 2 - To execute multiple Tests Together - testsuite(Bunch of TC's together)
 * 3 - To execute Multiple class together - classSuite(Bunch of Classes together)
 * 4 - To get graphical results (HTML Report), to showcase a execution evidence
 * 5 - To Record a test steps (Logs), error logs too
 * 6 - To run tests in a groups
 * 7 - To run tests in parallel
 * 8 - We have attributes 
 * 		a - To run test in bulk
 * 		b - priortize test
 * 		c - describe to your test
 * 		d - skip the test
 * 9 - We do have multiple annotation
 * 		
 * What is Annotation
 * Ans - It is well defined rule, to do some setup
 * 
 * inbox - 200(40)
 * outbox- 150(30)
 * sent- 100(20)
 * compose - 100(20)
 * 
 * drafs - 110(55%) - 200(chrome, edge, safari) - 4 hrs each - 12 Hrs
 */
}
