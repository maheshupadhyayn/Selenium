package testNGPkg;

import org.testng.annotations.Test;

public class ConceptTestNG {
	@Test
	public void TC1() {
		System.out.println("I am in testNG test");
	}
	public static void main(String[] args) {
		System.out.println("I am in main");
	}
}
/*
Can we convert normal java class into a TestNG class?
Ans - Yes, by including TestNG library to project & then add @Test annotation

Is there an error if main & @test both will be in same class?
Ans - No Error

Then which method will run (main() or @Test)
Ans - Both, how, we can run as java application for main
	and we can run as TestNG test
	
Can we run Test NG test without any other annotation?
Ans - Yes, only @Test annotation is mandatory to run
*/





