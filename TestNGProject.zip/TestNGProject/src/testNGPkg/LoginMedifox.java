package testNGPkg;

public class LoginMedifox {

}
