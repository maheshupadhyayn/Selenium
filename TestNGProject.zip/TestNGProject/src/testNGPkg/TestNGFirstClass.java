package testNGPkg;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.AfterSuite;

public class TestNGFirstClass {
  //Wherever @Test annotation mention before any method then that method is consider as test case
  @Test
  public void TC1() {
	  System.out.println("In TC1");
  }
  @Test
  public void TC2() {
	  System.out.println("In TC2");
  }
  //It will execute before each @Test (TC)
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("In Before Method");
  }
  //It will execute after each @Test (TC)
  @AfterMethod
  public void afterMethod() {
	  System.out.println("In After Method");
  }
  //It will execute before all @Test from same class only once
  @BeforeClass
  public void beforeClass() {
	  System.out.println("In Before Class");
  }
  //It will execute after all @Test from same class only once
  @AfterClass
  public void afterClass() {
	  System.out.println("In After Class");
  }
  //It will execute before all @Test from multiple classes only once
  @BeforeTest
  public void beforeTest() {
	  System.out.println("In Before Test");
  }
  //It will execute after all @Test from multiple classes only once
  @AfterTest
  public void afterTest() {
	  System.out.println("In After Test");
  }
  //It will execute only once before suite
  @BeforeSuite
  public void beforeSuite() {
	  System.out.println("In Before Suite");
  }
  //It will execute only once after suite
  @AfterSuite
  public void afterSuite() {
	  System.out.println("In after Suite");
  }

}
