package testNGScenarios;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class BeforeAllFeatureTest {
	WebDriver driver = null;
	@BeforeClass
	public void beforeAllestFromClass() {
		driver = new ChromeDriver();
	}
	@Test
	public void TC1() {
		driver.get("https://www.amazon.in");
	}
	@Test
	public void TC2() {
		driver.get("https://www.google.co.in");
	}
	@Test
	public void TC3() {
		driver.get("https://www.rediff.com");
	}
	@Test
	public void TC4() {
		driver.get("https://www.yahoo.com");
	}
	@AfterClass
	public void afterAllTestFromClass() {
		driver.close();
	}
}
