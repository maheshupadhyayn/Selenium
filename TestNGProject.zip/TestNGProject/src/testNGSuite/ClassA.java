package testNGSuite;

import org.testng.annotations.Test;

public class ClassA extends BaseClass{
	@Test
	public void TC1() {
		System.out.println("In TC1");
	}
	@Test
	public void TC2() {
		System.out.println("In TC2");
	}
}
/*
Can I run only 1 TC's from this call?
Ans - Yes, Select that Test, and right click run as-> testNG test*/