package testNGSuite;

import org.testng.annotations.Test;

public class ClassB extends BaseClass{
	@Test
	public void TC3() {
		System.out.println("In TC3");
	}
	@Test
	public void TC4() {
		System.out.println("In TC4");
	}
}
