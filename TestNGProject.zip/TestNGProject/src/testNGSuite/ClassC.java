package testNGSuite;

import org.testng.annotations.Test;

public class ClassC extends BaseClass{
	@Test
	public void TC5() {
		System.out.println("In TC5");
	}
	@Test
	public void TC6() {
		System.out.println("In TC6");
	}
}
