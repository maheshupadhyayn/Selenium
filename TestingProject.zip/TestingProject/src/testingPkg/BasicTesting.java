package testingPkg;

public class BasicTesting {
	public void login(String user, String pass) {
		
	}
/*
 * What is testing?
 * Ans - Verify a product/service meets your expectation or not
 * 
 * Product & Service
 * Ans - Product we can see, service is on top of product , we can't see
 * 
 * Which industry serves product & service?
 * Ans - Manufacturing & Software
 * 
 * What is software?
 * Ans- It is a program to perform certain action/task
 * 
 * How to define expectation?
 * Ans - By checking actual against expected
 * 
 * Where is this expected define?
 * Ans - SRS(Software Requirement Specification) - Its a document
 * 
 * What is User Story?
 * Ans - defination of done(DOD) for any feature
 * 
 * Testing Model?
 * 	1 - Waterfall model
 * 	2 - Agile Model
 * 
 * What is software Testing?
 * Ans- Verify your software meets your expectation or not
 * 
 * How many types of s/w testing?
 * Ans - there are 2 types
 * 		1 - Functional Testing
 * 			a - Smoke Testing - Automation
 * 			b - Sanity Testing - Automation
 * 			c - Regression Testing - Automation
 * 			d - Unit Testing - Automation
 * 			e - Integration Testing - Automation
 * 			f - Black box testing
 * 		2 - Non-Functional testing
 * 			a - Performance Testing
 * 			b - Load Testing
 * 			c - Soak Testing
 * 			d - Stress Testing
 * 			e - Usability Testing - Automation
 * 			f - Security Testing
 * 			g - Compatibility Testing
 * 
 * Build Cycle - Deployment from dev team for testing
 * If Sprint of 2 Week - 4th & 7th Day of Sprint deployment
 * If sprint of 3 Week - 6th & 12th Day of Sprint deployment
 * 
 * If total TC's are 400
 * 
 * Smoke Test - Build stability test within smoke test - 10 TC's(100% positive, no link broken) - 10mins(20 mins)*5 (100mins)
 * Sanity Test - Build Sustainability test within sanity test - 40 TC's(75% positive, 10% Negative) - 40mins*2 (80 mins)
 * Regression Test - Check existing feature breaks due to new deployment - 160 TC's(50%,50% +ve,-Ve) - 5Hrs(2 weeks once)
 * Unit Testing - Developer test develope function as a unit with all possible combination
 * System Integration Testing - Multiple feature clubs together we need to test integration
 * Black Box Testing - Random, Monkey Testing - to check without knowing feature/code - UI
 * Performance Testing - Concurrently 10 Users, i have to test application with 10 user(2,5,10)
 * Load Testing - I have to test application with 14 user (5, 10, 15)
 * Stress Test - I have to test application with continious user load (10, 20 ,30)
 * Soak Test - I have to test with spike (10 User/5 mins - 10 Hrs) - 3 days
 * Usability Test - How user is going to use application/user experience
 * Compatibility Test - Compatible with different version of s/w, OS & browser
 * Boundary Value Analysis - We test minimum, median, maximum & out of minimum and out of maximum
 * TestBox which accepts only 0-1000 (-1,0,501,1000,1001)
 * Security Testing - To check how your application is secure from outside threat
 */
}
/*
 * Collection
 * Xls,CSV
 * Properties
 */
