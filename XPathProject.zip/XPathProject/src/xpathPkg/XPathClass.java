package xpathPkg;

public class XPathClass {
	public static void main(String[] args) {
		/*
		 * What is Xpath - extended Path to identify your webelement
		 * 
		 * Syntax - //tagname[@attrName = 'attrValue']
		 * 
		 * OR
		 * "//input[@type='text' or @name='name']"
		 * 
		 * And
		 * "//input[@type='text' and @name='name']"
		 * If want to get all tags from the same page
		 * ("//*")
		 * 
		 * text()
		 * //*[text()='LOGIN']" - gettext(), value between ">" & "<"
		 * 
		 * Contains()
		 * //*[contains(text(), 'LOG')]
		 * //*[contains(@name, 'pass')]
		 * "(//*[contains(@name, 'pass')])[2]" - Index
		 * 
		 * Starts-with()
		 * "//*[starts-with(@name,'pass')]"
		 * 
		 * Advance XPath - Separate Axes - Sparate evaluation
		 * I need all input tags after first name
		 * "//input[@name='First_Name']//following::input"
		 * 
		 * I need all input tags after first name but type should be radio
		 * //input[@name='First_Name']//following::input[@type='radio']
		 * 
		 * I need all input tags before male radio button
		 * "//input[@value='Male']//preceding::input"
		 * 
		 * Switch to the parent from current node - first name
		 * "//input[@name='First_Name']//parent::td"
		 * "//input[@name='First_Name']//parent::td//parent::tr"
		 * "//input[@name='First_Name']//parent::td//parent::tr//parent::tbody//parent::table"
		 * Parent moves to immediate parent not ancestor
		 * 
		 * Switch to direct to dadaji(table)
		 * "//input[@name='First_Name']//ancestor::table"
		 * Ancestory moves to any level of parent
		 * 
		 * I want to get all childs from table
		 * "//table//child::input"
		 * 
		 * I want to get all siblings
		 * "//select[@name='Birthday_day']//following-sibling::select"
		 */
	}
}










